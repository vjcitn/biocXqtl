plink2 \
  --pfile all_hg38 vzs \
  --chr 19 \
  --maf 0.1 \
  --keep kp.txt \
  --make-pgen vzs \
  --allow-extra-chr \
  --out chr19_limsamples_pp1
