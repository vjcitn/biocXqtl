plink2 \
  --pfile chr19_limsamples_pp1 vzs \
  --make-bed \
  --out chr19_limsamples_maf10
